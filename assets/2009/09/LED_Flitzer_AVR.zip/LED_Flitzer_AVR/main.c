/*!
	 \file       main.c        
	 \Version    1.1
   \modified   various comments added                             
	 \copyright  (c) Sebastian Schuster ( info@zipfelmaus.com )    
	 \licence    GPL
	 \brief      main of LED-Flitzer    
	 \author     Sebastian Schuster
	 \date       2009/08/14    
   
   
   for ATmega8L, internal RC-Osc. 1MHz
   
   */  



#include <stdio.h> 
#include <stdlib.h> 
#include <stdint.h>

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include <avr/eeprom.h>
#include <inttypes.h>

#include "uart.h" 
#include "font.h" 

// Declare your global variables here
unsigned int ms_counter;

#define ADC_VREF_TYPE 0x00

#define LED_STR_GROESSE (36)
#define LED_STR_GROESSE_ZM (89)


//Prototypes
void LED_Ansteuerfunktion(uint8_t wert);



//*********************************************************************
//Declarations for EEPROM: 
// EEMEM wird bei aktuellen Versionen der avr-lib in eeprom.h definiert
// hier: definiere falls noch nicht bekannt ("alte" avr-libc)
#ifndef EEMEM
// alle Textstellen EEMEM im Quellcode durch __attribute__ ... ersetzen
#define EEMEM  __attribute__ ((section (".eeprom")))
#endif

uint8_t eeDatenByteArray1[] EEMEM = { 'Z','I','P','F','E','L','M', 'A' ,'U', 'S', '.', 'C','O','M', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '};

//*********************************************************************

volatile uint8_t string_msg[30];

// Timer 0 overflow interrupt service routine
ISR(TIMER0_OVF_vect)
{
  // Reinitialize Timer 0 value
  TCNT0=0x7F;
  ms_counter++;
}


//Convert an ASCII char to a "alphabet[28][5]"-array value (font.h)
uint8_t ConvASCII(uint8_t wert)
{
  if((wert>0x40)&&(wert<0x5B))
    return (wert - 0x41); //A-Z
  else if(wert==0x2E)
    return 26; //point
  else
    return 27; //nothing
}

//returns 1, if the character is finished
uint8_t LED_Font_an_LED(uint8_t buchstabe)
{
  static uint8_t flag_font_blank=0;
  static uint8_t blank_cnt=0;
  static uint8_t font_cnt=0;

  //switches between character and spacing (2 space-lines between two chars).
  if(flag_font_blank)
  {
	  LED_Ansteuerfunktion(alphabet[buchstabe][font_cnt]);  
    
	  if(font_cnt<(alphabet_cnt[buchstabe]-1))
    {
      font_cnt++;
	    flag_font_blank=1;
    }
    else
    {
      font_cnt=0;
	    flag_font_blank=0;
    }
    return 0;
  }
  else
  {
    LED_Ansteuerfunktion(0);     

	  if(blank_cnt<1)
    {
	    blank_cnt++;
      return 0;
	  }
	  else  
	  {
	    blank_cnt=0;
	    flag_font_blank=1;
	    return 1;
	  }
  }
}

//controlls the Port-Channels that switch the LEDs
void LED_Ansteuerfunktion(uint8_t wert)
{
  uint8_t i=0;

  for(i=0; i<8; i++)
  {
    switch(i)
    {
       case 0: if( ((wert>>i)&0x01) )
	             {
                 PORTD &= ~ (1<<PD3);
			         }
			         else
                 PORTD |= (1<<PD3);
			         break;
       case 1: if( ((wert>>i)&0x01) )
			         {
                 PORTD &= ~ (1<<PD4);
			         }
			         else
                 PORTD |= (1<<PD4);
			         break;
       case 2: if( ((wert>>i)&0x01) )
			         {
                 PORTD &= ~ (1<<PD5);
			         }
			         else
                 PORTD |= (1<<PD5);
			         break;
       case 3: if( ((wert>>i)&0x01) )
			         {
                 PORTD &= ~ (1<<PD6);
			         }
			         else
                 PORTD |= (1<<PD6);
			         break;
       case 4: if( ((wert>>i)&0x01) )
			         {
                 PORTD &= ~ (1<<PD7);
			         }
			         else
                 PORTD |= (1<<PD7);
			         break;
       case 5: if( ((wert>>i)&0x01) )
			         {
                 PORTB &= ~ (1<<PB0);
			         }
			         else
                 PORTB |= (1<<PB0);
			         break;
       case 6: if( ((wert>>i)&0x01) )
			         {
                 PORTB &= ~ (1<<PB1);
			         }
			         else
                 PORTB |= (1<<PB1);
			         break;
       case 7: if( ((wert>>i)&0x01) )
			         {
                 PORTB &= ~ (1<<PB2);
			         }
			         else
                 PORTB |= (1<<PB2);
			         break;
    }
  }
}


//reads out the ADC
uint16_t adc(uint8_t admux)
{
    ADCSRA  =  (1<<ADEN)  | (1<<ADPS1) | (1<<ADPS0);
    ADMUX   =  admux;
    ADMUX  |=  (1<<REFS1) | (1<<REFS0);
    ADCSRA |=  (1<<ADSC);
    while      (ADCSRA    & (1<<ADSC));
    uint16_t val     = ADCW;
    ADCSRA &= ~(1<<ADEN);
    return val;
}

//Checks the state of the switch-input
uint8_t USB_SIO_Button_Einlesen(void)
{
  uint8_t retval;

  if ( ! (PIND & (1 << PD2)) )
  {  sprintf(string_msg, "Button pressed, wait for new LED string\n\r");
     retval=1;
  }
  else
  {  sprintf(string_msg, "Button not pressed, start application\n\r");
     retval=0;
  }
  uart_puts(string_msg);
  
  return retval;
}




int main(void)
{
  // Declare your local variables here
  volatile unsigned int ms_3ms_timer=0;
  volatile unsigned int ms_10ms_timer=0;
  volatile unsigned int ms_100ms_timer=0;

  volatile uint8_t merker=0;
  volatile uint8_t adc_werte[10];
  volatile uint8_t adc_mittelwert_alt=0;
  volatile uint8_t adc_mittelwert_neu=0;
  volatile unsigned int  adc_mittelwert_temp=0;
  volatile uint8_t a=0; 
  volatile uint8_t i=0; 
  volatile uint8_t LED_ein=0;

  volatile uint8_t LED_zyklen=0; 
  volatile uint8_t uart_string[20];      // String max. 19 chars


  // Input/Output Ports initialization
  // Port B initialization
  // Func7=In Func6=In Func5=In Func4=In Func3=In Func2=Out Func1=Out Func0=Out 
  // State7=T State6=T State5=T State4=T State3=T State2=0 State1=0 State0=0 
  PORTB=0x07;
  DDRB=0x07;
  
  // Port C initialization
  // Func6=In Func5=Out Func4=Out Func3=Out Func2=In Func1=In Func0=In 
  // State6=T State5=1 State4=0 State3=0 State2=T State1=T State0=T 
  PORTC=0x20;
  DDRC=0x38;
  
  // Port D initialization
  // Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=In Func1=In Func0=In 
  // State7=0 State6=0 State5=0 State4=0 State3=0 State2=T State1=T State0=T 
  PORTD=0xF8;
  DDRD=0xF8;
  
  //for switch at PD2:
  PORTD |= (1<<PD2);    /* internal Pull-Up PD2 */
  
  
  // Timer/Counter 0 initialization
  // Clock source: System Clock
  // Clock value: 125,000 kHz
  TCCR0=0x02;
  TCNT0=0x7F;
  
  // Timer/Counter 1 initialization
  // Clock source: System Clock
  // Clock value: Timer 1 Stopped
  // Mode: Normal top=FFFFh
  // OC1A output: Discon.
  // OC1B output: Discon.
  // Noise Canceler: Off
  // Input Capture on Falling Edge
  // Timer 1 Overflow Interrupt: Off
  // Input Capture Interrupt: Off
  // Compare A Match Interrupt: Off
  // Compare B Match Interrupt: Off
  TCCR1A=0x00;
  TCCR1B=0x00;
  TCNT1H=0x00;
  TCNT1L=0x00;
  ICR1H=0x00;
  ICR1L=0x00;
  OCR1AH=0x00;
  OCR1AL=0x00;
  OCR1BH=0x00;
  OCR1BL=0x00;
  
  // Timer/Counter 2 initialization
  // Clock source: System Clock
  // Clock value: Timer 2 Stopped
  // Mode: Normal top=FFh
  // OC2 output: Disconnected
  ASSR=0x00;
  TCCR2=0x00;
  TCNT2=0x00;
  OCR2=0x00;
  
  // External Interrupt(s) initialization
  // INT0: Off
  // INT1: Off
  MCUCR=0x00;
   
  // Timer(s)/Counter(s) Interrupt(s) initialization
  TIMSK=0x01;
  
  // USART initialization
  // Communication Parameters: 8 Data, 1 Stop, No Parity
  // USART Receiver: On
  // USART Transmitter: On
  // USART Mode: Asynchronous
  // USART Baud Rate: 4800
  UCSRA=0x00;
  UCSRB=0x18;
  UCSRC=0x86;
  UBRRH=0x00;
  UBRRL=0x0C;
  
  // Analog Comparator initialization
  // Analog Comparator: Off
  // Analog Comparator Input Capture by Timer/Counter 1: Off
  ACSR=0x80;
  SFIOR=0x00;
  
  // ADC initialization
  // ADC Clock frequency: 125,000 kHz
  // ADC Voltage Reference: AREF pin
  ADMUX=ADC_VREF_TYPE & 0xff;
  ADCSRA=0x83;
  
  
  sprintf(string_msg, "LED-Flitzer, V0.1, USB-SIO\n\r");
  uart_puts(string_msg);
  
  for(i=0; i<sizeof(string_msg); i++)
  {
    string_msg[i] = '\0';
  }
  for(i=0; i<sizeof(uart_string); i++)
  {
    uart_string[i] = '\0';
  }
  
  
  //##########################################
  //Check if new data is available via USB
  if(USB_SIO_Button_Einlesen()) //Button is pressed
  {
    sprintf(string_msg, "Lese Daten SIO\n\r");
    uart_puts(string_msg);
    
    //read data from UART
    uart_gets( uart_string, sizeof( uart_string ) );
  
    // write to EEPROM
    eeprom_write_block(uart_string,eeDatenByteArray1,sizeof(eeDatenByteArray1));
  
  }
  else //no new USB-data, read data from EEPROM
  {
    sprintf(string_msg, "Lese EE aus\n\r");
    uart_puts(string_msg);
  
    for(i=0; i<sizeof(string_msg); i++)
    {
      string_msg[i] = '\0';
    }
   
    eeprom_read_block(uart_string,eeDatenByteArray1,sizeof(eeDatenByteArray1));
  
    sprintf(string_msg, "%s\n\r", uart_string);
    uart_puts(string_msg);
  
  }
  
  sprintf(string_msg, "Start:");
  uart_puts(string_msg);

  //Reset Timer-Vars
  ms_counter=0;
  ms_3ms_timer=0;
  ms_10ms_timer=0;
  ms_100ms_timer=0;
  
  sei();
  
  while (1)
  {

     if(ms_counter>=ms_10ms_timer) //10ms, ADC-Sampling
     {
       ms_10ms_timer=ms_counter+10;
       adc_werte[a]=(uint8_t)( (adc(1))>>2 ); //read from ADC-channel 1 -> y-axis Accelerometer
                    
       if(a<4) 
         a++;
       else
         a=0;
     }

     if(ms_counter>=ms_100ms_timer) //100ms
     {
       ms_100ms_timer=ms_counter+100;
			 
       for(i=0; i<5; i++)
         adc_mittelwert_temp+=adc_werte[i];

       adc_mittelwert_temp=adc_mittelwert_temp/5;
       adc_mittelwert_neu=(uint8_t)adc_mittelwert_temp; //Mean-value of y-axis Accelerometer

       if( (adc_mittelwert_neu>(adc_mittelwert_alt+20))| (adc_mittelwert_neu<(adc_mittelwert_alt-20))) //if movement was detected, start LEDs   
         LED_ein=1;
             
       adc_mittelwert_alt=adc_mittelwert_neu;
     }

     if(LED_ein)
		 {
       if(ms_counter>=ms_3ms_timer)  //3ms
       {
         ms_3ms_timer=ms_counter+2;

         if(LED_Font_an_LED(ConvASCII(uart_string[merker])))
         {
			   
           if(merker<sizeof(uart_string))
			       merker++;
           else
           {  merker=0;
              LED_Ansteuerfunktion(0x00);
              
              cli();
			        _delay_ms(10);
		    	    sei();
				
                
				      if(LED_zyklen>2)  //write text to LEDs three times
				      {
				        LED_ein=0;
				        LED_zyklen=0;
              }
				      else
				        LED_zyklen++;
           }
			   }

		  }
    }

  };

  return 0;
}
