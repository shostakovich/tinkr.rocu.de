#include <stdio.h> 
#include <stdlib.h> 
#include <stdint.h>

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>


/*
Status-LEDs: SMD-LEDs an PC6 und PC7 (0 ist aktiv)
Status-LEDs: DOU-LED  an PA6 und PA7 (1 ist aktiv)


*/

volatile unsigned char freq_val;

// Timer 1 overflow interrupt service routine
ISR(TIMER1_OVF_vect)
{
// Place your code here


  TCNT1=freq_val;
  asm volatile("nop");

}

volatile unsigned char freq_val;

// Timer 2 overflow interrupt service routine
ISR(TIMER2_OVF_vect)
{
// Place your code here


  TCNT2=freq_val;
  asm volatile("nop");

}

//intensity: 0 to 100
void Sweep_White(unsigned char intensity)
{

  if(intensity>100)
    intensity=100;


  float r_val = 1.58*(float)intensity + 97.0; 
  unsigned short int g_val = 11*intensity+100;
  unsigned short int b_val = 2*intensity+100;

  
  //Duty Cycle auf i%
  OCR2= (unsigned char)r_val;//(unsigned char)r_val;
  OCR1A=g_val; 
  OCR1B=b_val; 

}


/*
Wir denken uns einen Farbkreis:

 / R \
 B - G

Winkel 0� ist Rot, dann geht es im Uhrzeigersinn auf Gr�n (120�),
dann Blau (240�)
*/
void Farbkreis(unsigned short int kreiswinkel, unsigned char intensity)
{
  
  volatile float r_val = 0.0;
  volatile float g_val = 0.0;
  volatile float b_val = 0.0;
  
  
  if(intensity>100)
    intensity=100;


  if(kreiswinkel>359)
    kreiswinkel=0; 



  if(kreiswinkel<121) //Farbkreis zw Rot und Gr�n
  {
    r_val = (1.58*(120-(float)kreiswinkel)/1.2)*((float)intensity/100)   + 97.0; 
    g_val =  11.0*  ((float)kreiswinkel/1.2)*((float)intensity/100)      +100.0;
    b_val = 100.0; //aus
  }
  else if((kreiswinkel>120) &(kreiswinkel<241)) //Farbkreis zw Gr�n und Blau
  {
    r_val =  97.0; //aus
    g_val =  11.0*  ((120- ((float)kreiswinkel-120.0) )/1.2)*((float)intensity/100)  +100.0;
    b_val =  11.0*  (((float)kreiswinkel-120.0)/1.2)*((float)intensity/100)          +100.0;
  }
  else //Farbkreis zw Blau und Rot
  {
    r_val =  1.58*  (((float)kreiswinkel-240.0)/1.2)*((float)intensity/100)          +97.0;
	g_val = 100.0; //aus
	b_val =  11.0*  ((120- ((float)kreiswinkel-240.0) )/1.2)*((float)intensity/100)  +100.0;
  }

  
  //Duty Cycle auf i%
  OCR2= (unsigned char)r_val;//(unsigned char)r_val;
  OCR1A=(unsigned short int)g_val; 
  OCR1B=(unsigned short int)b_val;

}


void delay_ms_func(unsigned short int ms)
{
  volatile unsigned short int a,i;
   

  for(a=0; a<ms; a++)
  {
    for(i=0; i<1000; i++) //asume, we need 16 cycles per iteration
    {
      asm volatile("nop");
    }
  }

}


// Declare your global variables here

int main(void)
{
// Declare your local variables here

unsigned char Red_duty_cycle_cnt=0;
unsigned short int Green_duty_cycle_cnt=1200;
unsigned short int Blue_duty_cycle_cnt=0;

unsigned short int i=0;
unsigned short int helligkeit=0;


// Input/Output Ports initialization
// Port A initialization
// Func7=Out Func6=Out Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=0 State6=0 State5=T State4=T State3=T State2=T State1=T State0=T 
PORTA=0xC0;
DDRA=0xC0;

// Port B initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTB=0x00;
DDRB=0x00;

// Port C initialization
// Func7=Out Func6=Out Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=0 State6=0 State5=T State4=T State3=T State2=T State1=T State0=T 
PORTC=0x00;
DDRC=0xC0;

// Port D initialization
// Func7=Out Func6=In Func5=Out Func4=Out Func3=In Func2=In Func1=In Func0=In 
// State7=0 State6=T State5=0 State4=0 State3=T State2=T State1=T State0=T 
PORTD=0xB0;
DDRD=0xB0;



// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=FFh
// OC0 output: Disconnected
TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;



OCR1A = 0; // PWM einstellen, bevor der Timer startet
OCR1B = 0;
ICR1 = 1200;  // TOP-wert


TCCR1A = (1<<COM1A1) | (1<<COM1B1) | (1<<WGM11); // 2-Kanal "non-inverting"
TCCR1B = (1<<WGM13)|(1<<WGM12) | (1<<CS11); //Fastpwm, mit ICR1 als TOP

/*
// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 250,000 kHz
// Mode: Fast PWM top=OCR1A
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: On
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x03;
TCCR1B=0x1B;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

*/

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: 250,000 kHz
// Mode: Fast PWM top=FFh
// OC2 output: Non-Inverted PWM
ASSR=0x00;
TCCR2=0x6C;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=0x00;
MCUCSR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
//TIMSK=0x44;
TIMSK=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;



sei();

while (1)
      {
      // Place your code here




  Sweep_White(75);

/*
 Farbkreis(i++, 100);//helligkeit++);

 if(i>359)
   i=0;

 if(helligkeit>99)
   helligkeit=0;
*/


/*
tollstes wei�:
  //Duty Cycle auf i%
  OCR2=0;//100; //Red
  OCR1A=1200;//Green_duty_cycle_cnt;//Red_duty_cycle_cnt;
  OCR1B=300;//Blue_duty_cycle_cnt;
*/

 	  
		  freq_val=96;
		  delay_ms_func(50);


		  //_delay_ms(50);
 
/*
	    
		PORTD |= (1<<PD7);

        _delay_ms(500);

		PORTD &= ~ (1<<PD7);
		
		_delay_ms(500);

*/

      };

	  return 0;
}
