#include <inttypes.h>
#include <avr/io.h>


#ifndef _UART_H_
#define _UART_H_


void uart_putc(uint8_t c);
void uart_puts(uint8_t *data);

uint8_t uart_getc(void);
void uart_gets( char* Buffer, uint8_t MaxLen);



#endif 
