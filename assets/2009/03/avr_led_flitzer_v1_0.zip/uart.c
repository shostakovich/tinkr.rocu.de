#include <inttypes.h>
#include <avr/io.h>


#include "uart.h"

void uart_putc(uint8_t c)
{ // send one char per UART
   
    while (!(UCSRA & (1<<UDRE)));
    UDR = c;
}

void uart_puts(uint8_t *data)
{ // send string per UART
   
    while(*data)
    {
        uart_putc(*data);
        data++;
    }
}

/* Zeichen empfangen */
uint8_t uart_getc(void)
{
    while (!(UCSRA & (1<<RXC)))   // warten bis Zeichen verfuegbar
        ;
    return UDR;                   // Zeichen aus UDR an Aufrufer zurueckgeben
}
 
void uart_gets( char* Buffer, uint8_t MaxLen )
{
  uint8_t NextChar;
  uint8_t StringLen = 0;
 
  NextChar = uart_getc();         // Warte auf und empfange das n�chste Zeichen
 
                                  // Sammle solange Zeichen, bis:
                                  // * entweder das String Ende Zeichen kam
                                  // * oder das aufnehmende Array voll ist
  while( NextChar != '\n' && StringLen < MaxLen - 1 ) {
    *Buffer++ = NextChar;
    StringLen++;
    NextChar = uart_getc();
  }
 
                                  // Noch ein '\0' anh�ngen um einen Standard
                                  // C-String daraus zu machen
  *Buffer = '\0';
}
