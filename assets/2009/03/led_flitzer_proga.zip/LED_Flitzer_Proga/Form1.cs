﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO.Ports;
using System.Threading;

namespace LED_Flitzer_Proga
{
    public partial class Form1 : Form
    {
        bool senden_freigegeben;

        public Form1()
        {
            InitializeComponent();

            // Create a new SerialPort object with default settings.
            //comboBox1 = new ComboBox();

            linkLabel1.Links.Add(0, 0, "www.zipfelmaus.com");

            // Allow the user to set the appropriate properties.
            string[] ports = SerialPort.GetPortNames();

            foreach (string port in ports)
                comboBox1.Items.Add(port);

            //comboBox1.DropDownStyle = DropDownList;


            label_data_transfer.Text = "";
            senden_freigegeben = false;


        }

        private void Receive(string text)
        {
            richTextBox1.Text += text;
        }

        private delegate void ReceiveDelegate(string text);

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string message = serialPort1.ReadExisting();
            Invoke(
               new ReceiveDelegate(Receive),
               new Object[]
               {
                  message,
               });
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.Close();

            serialPort1.PortName = comboBox1.SelectedItem.ToString();
            serialPort1.BaudRate = 4800;
            serialPort1.Parity = Parity.None;
            serialPort1.DataBits = 8;
            serialPort1.StopBits = StopBits.One;
            serialPort1.Handshake = Handshake.None;

            // Set the read/write timeouts
            //            serialPort1.ReadTimeout = 500;
            //            serialPort1.WriteTimeout = 500;

            try
            {
                serialPort1.Open();
                errorProvider1.SetError(comboBox1, "");
            }
            catch (Exception)
            {
                errorProvider1.SetError(comboBox1, "besetzt");
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int temp_wert = 0;

            temp_wert = (15 - textBox1.TextLength);

            if (temp_wert >= 0)
                label_text_cnt.Text = temp_wert.ToString();
            else
                label_text_cnt.Text = "too many chars";

            bool ok = true;

            senden_freigegeben = true;

            foreach (char c in textBox1.Text)
            {
                if (!(('A' <= c) && (c <= 'Z')))
                {
                    ok = false;
                    senden_freigegeben = false;
                }
            }

            errorProvider1.SetError(textBox1, ok ? "" : "only letters allowed");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (serialPort1.IsOpen)
            {
                if (senden_freigegeben)
                {
                    serialPort1.WriteLine(textBox1.Text + "\n\r\n");
                    label_data_transfer.Text = "ok";
                }
                else
                    label_data_transfer.Text = "wrong characters used";
            }
            else
                label_data_transfer.Text = "COM-port not open";
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            serialPort1.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString()); 
        }

    }
}


