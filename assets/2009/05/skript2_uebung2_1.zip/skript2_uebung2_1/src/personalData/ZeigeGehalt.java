package personalData;


public class ZeigeGehalt {

    Personal[] personal_arr = new Personal[2];
    
    personal_arr[0] = new Personal();
    personal_arr[1] = new Personal();

    
	public ZeigeGehalt(){
	   personal_arr[0].set_name("Hans Maulwurf");
	   personal_arr[0].set_sozVersNr(12345);
	   personal_arr[0].set_gehalt(100);
		  
	   personal_arr[1].set_name("Krtek");
	   personal_arr[1].set_sozVersNr(21212);
	   personal_arr[1].set_gehalt(200000);
	}
	
	
	public static void main(String[] args) {
	
	
  
  
    }
}
