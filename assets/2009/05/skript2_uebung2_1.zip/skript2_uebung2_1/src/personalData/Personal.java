package personalData;

public class Personal {
	
	private String name;
	private int sozVersNr;
	private double gehalt;
	
	
	public Personal(String n, int nr, double geld)
	{
		name=n;
		sozVersNr=nr;
		gehalt=geld;
	}
	
	public Personal()
	{
		this("Jon Doe", 1, 0);
	}
	
	protected String get_name(){
		return name;
	}
	protected int get_sozVersNr(){
		return sozVersNr;
	}
	protected double get_gehalt(){
		return gehalt;
	}
	
	protected void set_name(String str){
		name=str;
	}
	protected void set_sozVersNr(int nr){
		sozVersNr=nr;
	}
	protected void set_gehalt(double geld){
		gehalt=geld;
	}
	
}
