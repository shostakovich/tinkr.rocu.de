<?php
/*
Plugin Name: YaCy Statistiken
Plugin URI: http://www.zipfelmaus.com
Description: This plugin displays stats of your YaCy Peer
Version: 0.1 Alpha
Author: Robert Curth
Author URI: http://www.zipfelmaus.com
*/

/*
Copyright (C) 2009 Robert Curth

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

register_sidebar_widget("YaCy Statistiken", "yacyStatsWidget");
register_widget_control('YaCy Statistiken', 'yacyStatsWidgetControll');


function yacyGetPeerStats($options)
{
  if(empty($options["peer_url"]))
  {
    return;
  }
  if(empty($options["cache"]) || empty($options["last_access"]) || $options["last_access"] < time()-$options["cache_time"])
  {
	try{
	  $result = @simplexml_load_file($options["peer_url"]."/Network.xml");	
	  $stats["ppm"] = (int)$result->your->ppm;
	  $stats["name"] = (string)$result->your->name;
	  $stats["words"] = (int)$result->your->words;
	  $stats["links"] = (int)$result->your->links;
      $stats["type"] = (string)$result->your->type;
	  if(!empty($stats["name"]))
	  {
		$options["last_access"] = time();		
        $options["cache"] = serialize($stats);
        update_option('yacy_options', $options);
      }
      else
      {
	    return;
      }
    }catch(Exception $e)
    {
	  return;
    }  
  }
  else
  {
	$stats = unserialize($options["cache"]);
  }
  return $stats;
}

function yacyStatsWidget($args)
{
	$options = get_option('yacy_options');
	$stats = yacyGetPeerStats($options);
	if(empty($stats))
	{
      return;
	}
	extract($args);
	?>
	<?php echo $before_widget; ?>
	<?php echo $before_title; ?><?php echo $options["title"] ?><?php echo $after_title; ?>
	<style type="text/css">
	  	#yacyStats dt{font-weight: 700; float: left; width: 30%;}
		#yacyStats dd{float: right; width: 70%; clear: right;}
    </style>
    <dl id="yacyStats">
      <dt>Peername</dt>
      <dd><?php printf("%s (%s)", $stats["name"], $stats["type"]); ?></dd>
      <dt>PPM</dt>
      <dd><?php echo $stats["ppm"] ?></dd>
      <dt>Wörter</dt>
      <dd><?php echo $stats["words"] ?></dt>
      <dt>URL's</dt>
      <dd><?php echo $stats["links"] ?></dt>
    </dl>
	<?php echo $after_widget;
}

function yacyStatsWidgetControll()
{
		$new_options = $options = get_option('yacy_options');
						
		if ( $_POST["yacy-widget"] )
		{
			$new_options['title'] = strip_tags(stripslashes($_POST["yacy-title"]));
		}
		if ( $_POST["yacy-peer-url"] )
		{
			$new_options['peer_url'] = strip_tags(stripslashes($_POST["yacy-peer-url"]));
		}
		if ( $_POST["yacy-cache_time"] )
		{
			$new_options['cache_time'] = intval($_POST["yacy-cache_time"]);
		}
		
		if ( empty($new_options['cache_time']) )
		{
			$new_options['cache_time'] = 60;
	    }
		if ( empty($new_options['title']) )
		{
			$new_options['title'] = 'YaCy Statistiken';
	    }
		if ( $options != $new_options )
		{
			$options = $new_options;
			update_option('yacy_options', $options);
		}
		$title = htmlspecialchars($options['title'], ENT_QUOTES);
		$peer_url = htmlspecialchars($options['peer_url'], ENT_QUOTES);
		$cache_time = $options["cache_time"];
	?>
	<p><label for="yacy-title"><?php _e('Title:'); ?><input name="yacy-title" type="text" value="<?php echo $title; ?>" /></label></p>
	<p><label for="yacy-peer-url"><?php _e('Peer-URL:'); ?><input name="yacy-peer-url" type="text" value="<?php echo $peer_url; ?>" /></label></p>
	<p><label for="yacy-cache_time"><?php _e('Cache-Zeit:'); ?><input name="yacy-cache_time" type="text" value="<?php echo $cache_time; ?>" /></label></p>
	<input type="hidden" id="akismet-submit" name="yacy-widget" value="1" />
	<?php
}